package com.userapi.userrestapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserrestapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
