package com.userapi.userrestapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserrestapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserrestapiApplication.class, args);
	}

}
